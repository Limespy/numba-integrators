# Numba Integrators

[![PyPI Package latest release](https://img.shields.io/pypi/v/numba-integrators.svg)][1]
[![PyPI Wheel](https://img.shields.io/pypi/wheel/numba-integrators.svg)][1]
[![Supported versions](https://img.shields.io/pypi/pyversions/numba-integrators.svg)][1]
[![Supported implementations](https://img.shields.io/pypi/implementation/numba-integrators.svg)][1]

Numerical integrators using Numba

[1]: <https://pypi.org/project/numba-integrators> ""
